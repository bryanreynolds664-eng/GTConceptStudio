# Build a signed APK from an iPhone using GitHub Actions

This project includes a manual GitHub Actions workflow at `.github/workflows/android-release.yml`. It builds and verifies a signed APK in GitHub's hosted Android build environment. It does not publish or deploy the app.

## Important privacy steps

- Do not commit `GTConceptStudio-release.jks`, `keystore.properties`, or any credential file.
- Keep the JKS private. Use a private GitHub repository you control.
- GitHub Actions secrets are used for signing credentials. Never place passwords directly in workflow YAML or source code.

## One-time setup

1. Create a **private** GitHub repository from these project files, excluding `GTConceptStudio-release.jks`, `keystore.properties`, and `GTConceptStudio_PRIVATE_SIGNING_CREDENTIALS.txt`.
2. In the repository, open **Settings → Secrets and variables → Actions → New repository secret** and add:
   - `ANDROID_KEYSTORE_BASE64`: the Base64 text of the `.jks` file, generated locally with `base64 -w 0 GTConceptStudio-release.jks` on Linux/macOS. Do not paste the key into ChatGPT.
   - `ANDROID_STORE_PASSWORD`: the keystore password from your private credentials backup.
   - `ANDROID_KEY_PASSWORD`: the private-key password from that backup.
3. Open **Actions → Build and verify signed Android APK → Run workflow**.
4. When the run succeeds, open its summary and download the `GTConceptStudio-signed-release-apk` artifact. GitHub stores this artifact for seven days.
5. The workflow runs `apksigner verify --verbose --print-certs` before the artifact is uploaded. A failed verification makes the workflow fail.

## Current limitations

- This builds a standalone concept app with application ID `com.gtconceptstudio.angel20`; it does not modify or replace the prior app.
- The workflow has not been run from this prepared archive. An APK is not included until you upload the project to your private repository and run the workflow.
- If using an iPhone only, repository setup and secret entry can be done in GitHub's mobile website, but creating the Base64 secret is easiest on a computer. Keep the signing key confidential.
