#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
APK="${1:-app/build/outputs/apk/release/app-release.apk}"
if [[ ! -f "$APK" ]]; then echo "ERROR: APK not found: $APK" >&2; exit 1; fi
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
APKSIGNER=""
if [[ -n "$SDK" && -d "$SDK/build-tools" ]]; then
  APKSIGNER="$(find "$SDK/build-tools" -type f -name apksigner 2>/dev/null | sort -V | tail -n 1)"
fi
if [[ -z "$APKSIGNER" ]]; then
  if command -v apksigner >/dev/null 2>&1; then APKSIGNER="$(command -v apksigner)"; fi
fi
if [[ -z "$APKSIGNER" ]]; then echo "ERROR: apksigner not found. Install Android SDK Build-Tools and set ANDROID_HOME." >&2; exit 1; fi
"$APKSIGNER" verify --verbose --print-certs "$APK"
