#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v java >/dev/null 2>&1; then echo "ERROR: Java/JDK not found. Install JDK 17." >&2; exit 1; fi
if [[ -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" ]]; then
  echo "ERROR: Set ANDROID_HOME or ANDROID_SDK_ROOT to your Android SDK path." >&2; exit 1
fi
if [[ ! -f keystore.properties ]]; then
  echo "ERROR: keystore.properties is missing. Copy keystore.properties.example to keystore.properties and enter credentials locally." >&2; exit 1
fi
if [[ ! -f GTConceptStudio-release.jks ]]; then
  echo "ERROR: GTConceptStudio-release.jks is missing from project root." >&2; exit 1
fi
if [[ -x ./gradlew ]]; then
  ./gradlew --no-daemon clean assembleRelease
elif command -v gradle >/dev/null 2>&1; then
  gradle --no-daemon clean assembleRelease
else
  echo "ERROR: Gradle not found. Open this folder in Android Studio or install Gradle / add the Gradle wrapper." >&2; exit 1
fi
APK="app/build/outputs/apk/release/app-release.apk"
if [[ ! -f "$APK" ]]; then echo "ERROR: Build finished but expected APK not found at $APK" >&2; exit 1; fi
printf '
Release APK created: %s/%s
' "$PWD" "$APK"
echo "IMPORTANT: Run verify_release.sh before installing or sharing the APK."
