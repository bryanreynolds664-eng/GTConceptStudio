package com.gtconceptstudio.angel20;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.Gravity;
import android.util.TypedValue;

public class MainActivity extends Activity {
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(5, 6, 12));
        getWindow().setNavigationBarColor(Color.rgb(5, 6, 12));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(5, 6, 12));

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14), dp(14), dp(14), dp(18));
        page.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("GT CONCEPT STUDIO  •  ANGEL CONCEPT 20");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        title.setGravity(Gravity.CENTER);
        title.setLetterSpacing(0.04f);
        title.setPadding(dp(4), dp(12), dp(4), dp(12));
        page.addView(title, new LinearLayout.LayoutParams(-1, -2));

        ImageView poster = new ImageView(this);
        poster.setImageResource(R.drawable.angel_concept_poster);
        poster.setAdjustViewBounds(true);
        poster.setScaleType(ImageView.ScaleType.FIT_CENTER);
        poster.setContentDescription("GT Concept Studio Angel Concept 20 prototype concept poster with B&A signature branding and chameleon metallic finish");
        page.addView(poster, new LinearLayout.LayoutParams(-1, -2));

        TextView note = new TextView(this);
        note.setText("PROTOTYPE CONCEPT • NOT FOR SALE\nDesign visualization only. Specifications and safety features are conceptual and require engineering validation.");
        note.setTextColor(Color.rgb(165, 178, 201));
        note.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        note.setGravity(Gravity.CENTER);
        note.setPadding(dp(8), dp(14), dp(8), dp(12));
        page.addView(note, new LinearLayout.LayoutParams(-1, -2));

        scroll.addView(page);
        setContentView(scroll);
    }
}
