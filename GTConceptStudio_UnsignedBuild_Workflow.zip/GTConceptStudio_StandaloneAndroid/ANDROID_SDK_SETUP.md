# Android SDK setup and signing guide — GT Concept Studio

This package is a standalone Android Studio project. It does not use Base44, and it does not publish or deploy anything.

## 1. Install the build tools

On a computer, install Android Studio and its Android SDK components:
- JDK 17 (Android Studio's bundled JBR is usually suitable)
- Android SDK Platform 35
- Android SDK Build-Tools (install a current version through SDK Manager)
- Gradle 8.9+ if building from the command line without a Gradle wrapper

The project uses Android Gradle Plugin 8.7.3 and `compileSdk 35`. Gradle may need internet access once to download the plugin and dependencies.

## 2. Add private signing material

Copy the separately provided `GTConceptStudio-release.jks` into this project root, alongside `settings.gradle`.

Copy `keystore.properties.example` to `keystore.properties`, then replace the placeholders with the values from your private credentials backup. Keep both files private. Do not paste passwords into chat, commit them to source control, or put them in the ZIP you share.

Expected properties:
- `storeFile=GTConceptStudio-release.jks`
- `storePassword=<your-keystore-password>`
- `keyAlias=gtconceptstudio`
- `keyPassword=<your-key-password>`

The keystore file path is relative to the project root. The Gradle config only wires release signing when `keystore.properties` exists.

## 3. Build the release APK

From a terminal in this folder, set `ANDROID_HOME` or `ANDROID_SDK_ROOT` to the SDK location, then run:

```bash
./build_release.sh
```

If no Gradle wrapper is included, install Gradle or open the project in Android Studio and sync it first. In Android Studio, choose **Build → Generate Signed Bundle / APK → APK → release** and point it to the same keystore and alias.

Expected output:
`app/build/outputs/apk/release/app-release.apk`

## 4. Verify the signature

Run:

```bash
./verify_release.sh
```

The script uses Android SDK `apksigner` and prints the signing certificate information. A successful build alone is not proof of signature validity; verify before installing.

## 5. Security and compatibility

- The `.jks` and `keystore.properties` files are ignored by Git.
- Keep at least two secure backups of the keystore and credentials.
- Never upload the keystore to a public repository or share it with an untrusted builder.
- A new key signs this standalone app identity only. The current application ID is `com.gtconceptstudio.angel20`, so it is not guaranteed to update or replace a previous APK.
- This starter is a visual concept shell, not a complete recreation of the previous web app.
- No APK is included in this setup package, and no build/signature verification was performed in this environment because Android SDK, Gradle and `apksigner` are not installed here.
- No purchase, publication or deployment has been performed.

## Files added in this setup pack

- `build_release.sh` — prerequisite checks and release build command
- `verify_release.sh` — signature verification with `apksigner`
- `.gitignore` — excludes local secrets and build output
- `keystore.properties.example` — template only; contains no real credentials
