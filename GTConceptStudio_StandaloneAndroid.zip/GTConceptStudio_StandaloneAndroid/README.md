# GT Concept Studio — Standalone Android starter

This is a standalone Android Studio project shell using the generated GT Concept Studio / Angel Concept 20 concept poster as local app artwork. It does not connect to Base44 and does not alter the existing Base44 app.

## Build prerequisites
- Android Studio with Android SDK Platform 35 and a compatible JDK
- Internet access for Gradle to download the Android Gradle Plugin and dependencies

## Build an APK
1. Open this folder in Android Studio.
2. Allow Gradle sync to finish.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. For a signed release, select **Build > Generate Signed Bundle / APK > APK**, create or select a private keystore, and complete the wizard.
5. Keep the keystore and passwords private and backed up. An APK signed with a new key will not update an app installed under a different signing key.

## Important
- This project is a visual concept shell, not a full recreation of the prior Base44 web app.
- No APK has been built or signed in this environment because Android SDK / Gradle / apksigner tooling is unavailable here.
- This starter uses a new application ID `com.gtconceptstudio.angel20`; it will install as a separate app and cannot replace the prior app unless the original application ID, source, and compatible signing key are available.
- No purchasing, publishing, or deployment has been performed.
