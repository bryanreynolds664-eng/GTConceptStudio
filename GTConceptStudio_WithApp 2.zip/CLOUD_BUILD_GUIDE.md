# Build a debug APK from your phone using GitHub Actions

This project includes a manual GitHub Actions workflow at `.github/workflows/android-debug.yml`. It builds an **unsigned-for-release debug APK** (signed automatically with Android's standard debug key) in GitHub's hosted environment. It does not publish or deploy anything, and it needs **no secrets or keystore**.

## One-time setup

1. Create a **private** GitHub repository.
2. Upload the *contents* of this project to the repository root, so `settings.gradle` and the `.github` folder sit at the top level (not inside a sub-folder). GitHub only detects workflows in `.github/workflows/` at the repository root.
3. Open **Actions → Build GT Concept Studio Debug APK → Run workflow**.
4. When the run succeeds, open its summary and download the `GTConceptStudio-debug-apk` artifact (kept for 7 days). Unzip it and install the APK on your Android device (allow installs from your browser or file manager when prompted).

## Signed release builds (later, optional)

Release signing is not part of the cloud workflow. To make a signed release APK, use a computer with Android Studio or the SDK: see `README.md` and `build_release.sh`. Never commit `GTConceptStudio-release.jks`, `keystore.properties`, or any credential file; `.gitignore` already excludes them.

## Notes

- Application ID is `com.gtconceptstudio.angel20`; it installs as a separate app and does not replace any earlier app.
- The workflow has not been run from this archive. If a run fails, open the failed step's log and share the error.
