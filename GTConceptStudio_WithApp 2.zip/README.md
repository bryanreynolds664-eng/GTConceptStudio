# GT Concept Studio — Standalone Android starter

This is a standalone Android Studio project that bundles the GT Concept 20 Angel interactive page (`app/src/main/assets/index.html`) inside a WebView. It works offline except for the web fonts, which fall back to system fonts. It does not connect to Base44 and does not alter the existing Base44 app.

## Build prerequisites
- Android Studio with Android SDK Platform 35 and a compatible JDK
- Internet access for Gradle to download the Android Gradle Plugin and dependencies

## Quick test build (no signing)
Push this project to a private GitHub repo (files at the repo root) and run the **Build GT Concept Studio Debug APK** workflow; see `CLOUD_BUILD_GUIDE.md`. It produces an installable debug APK with no keystore needed.

## Release signing setup
A new Android Java KeyStore (JKS) was generated separately for this project. Keep the `.jks` file and its password backup private. Do not commit them to source control or send them to anyone.

1. Place `GTConceptStudio-release.jks` in this project root (next to `settings.gradle`).
2. Copy `keystore.properties.example` to `keystore.properties`.
3. Fill in `storePassword` and `keyPassword` from the separate private credentials file. Keep the alias `gtconceptstudio` and store file name as shown.
4. In Android Studio, sync Gradle, then choose **Build > Generate Signed Bundle / APK > APK** and select the release variant. With `keystore.properties` configured, the release build is wired to the generated key.
5. Alternatively, run `./gradlew assembleRelease` from the project root (needs a Gradle install or wrapper; run `gradle wrapper --gradle-version 8.9` once to create `gradlew`) after Android SDK/Gradle prerequisites are installed. The signed APK should be at `app/build/outputs/apk/release/app-release.apk`.
6. Verify the APK using Android SDK Build Tools `apksigner verify --verbose --print-certs app/build/outputs/apk/release/app-release.apk`.

Do not put passwords in `build.gradle`, commit `keystore.properties`, or upload the private keystore to public repositories. Keep at least two secure backups of the keystore and credentials. If the key is lost, updates signed with this key may no longer be possible.

## Important
- This project is a visual concept shell, not a full recreation of the prior Base44 web app.
- The environment used to prepare these files has Java and `keytool`, but does not have Android SDK / Gradle / `apksigner` tooling, so no APK has been built or signed here. The keystore itself has been generated.
- This starter uses application ID `com.gtconceptstudio.angel20`; it installs as a separate app and cannot replace the prior app unless the original application ID, source, and compatible signing key are available.
- The bike is a prototype concept; the artwork and specifications are illustrative and require engineering validation.
- No purchasing, publishing, or deployment has been performed.
